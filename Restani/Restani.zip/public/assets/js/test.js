if (condition) {

} else {

}