    <div class="table-responsive-lg">
        <table class="table table-borderless border d-sm-none d-lg-table collapse">
            <thead class="bg-primary text-white">
                <tr>
                    <th scope="col">Gambar</th>
                    <th scope="col">Produk</th>
                    <th scope="col">Harga</th>
                    <th scope="col">Jumlah</th>
                    <th scope="col">Subtotal</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $count = 0; ?>
                <tbody id="toko<?php echo e($user->id); ?>">
                    <?php
                        $invoice = [];
                    ?>
                    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($cart->product->user_id == $user->id): ?>
                            <?php
                                $total += $cart->total;
                                $buy = [
                                    'mitra_id' => $cart->product->user_id,
                                    'title' => $cart->product->title,
                                    'jumlah' => $cart->jumlah,
                                    'subtotal' => $cart->total,
                                ];
                                array_push($invoice, $buy);
                            ?>
                            <tr>
                                <td>
                                    <?php
                                $decode = json_decode($cart->product->foto, true);
                                for ($i=0; $i < 1 ; $i++) { 
                                ?>
                                    <img src="<?php echo e(asset('product/' . $decode[0])); ?>"
                                        class="img-fluid img-thumbnail text-center border rounded" alt=".."
                                        style="height: 40px;width:50px;object-position: center;overflow: hidden;object-fit: cover;">
                                    <?php } ?>

                                </td>
                                <td><?php echo e(Str::limit($cart->product->title, 50)); ?></td>
                                <td>Rp <span id="harga<?php echo e($cart->id); ?>"><?php echo e($cart->product->harga); ?></span></td>
                                
                                <td>
                                    <div class="number-input border-0">
                                        <button
                                            onclick="this.parentNode.querySelector('input[type=number]').stepDown() ,cartUpdate(<?php echo e($cart->id); ?>)"
                                            class="minus text-white bg-success"
                                            style="border-top-left-radius: 50%;border-bottom-left-radius: 50%;"></button>
                                        <input id="jumlah<?php echo e($cart->id); ?>" class="quantity border-0 text-center"
                                            min="1" max="<?php echo e($cart->product->stok); ?>" name="quantity"
                                            value="<?php echo e($cart->jumlah); ?>" type="number" disabled style="width: 50px">
                                        <button
                                            onclick="this.parentNode.querySelector('input[type=number]').stepUp() ,cartUpdate(<?php echo e($cart->id); ?>)"
                                            class="plus text-white bg-success"
                                            style="border-top-right-radius: 50%; border-bottom-right-radius: 50%;"></button>
                                    </div>
                                </td>
                                <td id="subtotal<?php echo e($cart->id); ?>" class="subtotal"><?php echo e($cart->total); ?></td>
                                <td class="text-center">
                                    <a class="mx-1" onclick="cartDelete(<?php echo e($cart->id); ?>)" href="#"><i
                                            class="fa fa-times link-danger"></i></a>
                                </td>
                            </tr>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr class=" text-right">

                        <th scope="col"><img src="<?php echo e(asset('assets/avatar/' . $user->avatar)); ?>"
                                class="img-thumbnail float-left" width="40" alt=""><span
                                class="fw-bold float-left m-2 text-capitalize"><?php echo e($user->name); ?></span></th>
                        <th scope="col"></th>
                        <th scope="col"></th>
                        <th scope="col"></th>
                        <th scope="col"></th>

                        <th scope="col">
                            <?php if(auth()->guard()->check()): ?>
                                <span class="h5 fw-bold text-black-50">Total</span>

                                <span class="h5 ml-2 fw-bold text-success">Rp <?php echo e($total); ?></span>
                                <a href="https://wa.me/<?php echo e($user->no_telp); ?>?text= *Checkout!*%0A Hallo kak saya <?php echo e(Auth::user()->name); ?>, %0A _Produk yg saya pesan_ %0A  %0A <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($i++); ?>. <?php echo e($buys['title']); ?>  %0A     jumlah x <?php echo e($buys['jumlah']); ?> = *Rp <?php echo e($buys['subtotal']); ?>* %0A <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> %0A *Total = Rp <?php echo e($total); ?>*"
                                    target="_blank" class="btn btn-success rounded-6 text-capitalize ml-4">Checkout</a>
                            <?php endif; ?>

                        </th>
                    </tr>

                </tbody>


                <?php $__currentLoopData = $title; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($prod['mitra_id'] == $user->id): ?>
                        <?php $count = count($title); ?>
                        <?php
                            $total = 0;
                        ?>
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                
                <?php if($count == 0): ?>
                    <style>
                        #toko<?php echo e($user->id); ?> {
                            display: none;
                        }

                    </style>
                <?php endif; ?>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>


    

    <div class="card d-sm-block d-lg-none">
        <div class="card-header rounded-9 bg-primary">
            <h5 class="text-white text-center">Keranjang</h5>
        </div>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $count = 0; ?>
            <div class="card-body" id="toko<?php echo e($user->id); ?>">
                <img src="<?php echo e(asset('assets/avatar/' . $user->avatar)); ?>" class="img-thumbnail float-left" width="40"
                    alt=""><span class="fw-bold float-left m-2 text-capitalize"><?php echo e($user->name); ?></span>
            </div>
            <div class="card-body mt-n4" id="toko<?php echo e($user->id); ?>">
                <?php
                    $invoice = [];
                ?>
                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($cart->product->user_id == $user->id): ?>
                        <?php
                            $total += $cart->total;
                            $buy = [
                                'mitra_id' => $cart->product->user_id,
                                'title' => $cart->product->title,
                                'jumlah' => $cart->jumlah,
                                'subtotal' => $cart->total,
                            ];
                            array_push($invoice, $buy);
                        ?>
                        <!-- loop -->
                        <div class="row border-top py-4">
                            <?php
                            $decode = json_decode($cart->product->foto, true);
                            for ($i=0; $i < 1 ; $i++) { 
                            ?>
                            <div class="col-4">
                                <a href="#">
                                    <img src="<?php echo e(asset('product/' . $decode[0])); ?>" class="img-fluid rounded" alt=""
                                        style="height: 60px;width:130px;object-position: center;overflow: hidden;object-fit: cover;">
                                </a>

                                <p class="text-success fw-bold mt-4 "><span>Rp <?php echo e($cart->total); ?></span></p>
                            </div>
                            <?php } ?>
                            <div class="col-8 align-self-center">
                                <div class="position-absolute" style="right: 0">
                                    <a class="mx-1" onclick="cartDelete(<?php echo e($cart->id); ?>)" href="#"><i
                                            class="fa fa-trash link-danger"></i></a>
                                </div>


                                <p><?php echo e(Str::limit($cart->product->title, 100)); ?></p>
                                <p class="fw-bold">Rp <span
                                        id="harga<?php echo e($cart->id); ?>"><?php echo e($cart->product->harga); ?></span></p>
                                <p id="subtotal<?php echo e($cart->id); ?>" class="subtotal"></p>


                                <div class="number-input form-group border-0 float-right">
                                    <button
                                        onclick="this.parentNode.querySelector('input[type=number]').stepDown() ,cartUpdateM(<?php echo e($cart->id); ?>)"
                                        class="minus text-white bg-success"
                                        style="border-top-left-radius: 50%;border-bottom-left-radius: 50%;"></button>
                                    <input id="jumlahM<?php echo e($cart->id); ?>" class="border text-center" min="1"
                                        name="quantity" value="<?php echo e($cart->jumlah); ?>" type="number"
                                        style="width: 50px;" disabled>
                                    <button
                                        onclick="this.parentNode.querySelector('input[type=number]').stepUp() ,cartUpdateM(<?php echo e($cart->id); ?>)"
                                        class="plus text-white bg-success"
                                        style="border-top-right-radius: 50%; border-bottom-right-radius: 50%;"></button>
                                </div>
                            </div>
                        </div>
                        <!-- break -->
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(auth()->guard()->check()): ?>
                    <div class="card-footer">
                        <div class="float-right">
                            <span class="text-black">Total : </span><span class="text-success fw-bold">Rp
                                <?php echo e($total); ?></span>
                        </div>
                    </div>
                    <a href="https://wa.me/<?php echo e($user->no_telp); ?>?text= *Checkout!*%0A Hallo kak saya <?php echo e(Auth::user()->name); ?>, %0A _Produk yg saya pesan_ %0A  %0A <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($i++); ?>. <?php echo e($buys['title']); ?>  %0A     jumlah x <?php echo e($buys['jumlah']); ?> = *Rp <?php echo e($buys['subtotal']); ?>* %0A <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> %0A *Total = Rp <?php echo e($total); ?>*"
                        target="_blank" class="btn btn-success rounded-6 text-capitalize">Checkout</a>
                <?php endif; ?>
            </div>



            <?php $__currentLoopData = $title; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($prod['mitra_id'] == $user->id): ?>
                    <?php $count = count($title); ?>
                    <?php
                        $total = 0;
                    ?>
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php if($count == 0): ?>
                <style>
                    #toko<?php echo e($user->id); ?> {
                        display: none;
                    }

                </style>
            <?php endif; ?>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php /**PATH D:\Server\htdocs\joki\Restani\Restani\resources\views/shop/elements/cart.blade.php ENDPATH**/ ?>