<?php if($num > 0): ?>
    Penilaian Produk : <br>
    <?php if($mean / count($ratting) > 0 && $mean / count($ratting) < 2): ?>
        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
        <span class="fa fa-star" style="font-size: 14px;"></span>
        <span class="fa fa-star" style="font-size: 14px;"></span>
        <span class="fa fa-star" style="font-size: 14px;"></span>
        <span class="fa fa-star" style="font-size: 14px;"></span>
    <?php endif; ?>
    <?php if($mean / count($ratting) >= 2 && $mean / count($ratting) < 3): ?>
        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
        <span class="fa fa-star" style="font-size: 14px;"></span>
        <span class="fa fa-star" style="font-size: 14px;"></span>
        <span class="fa fa-star" style="font-size: 14px;"></span>
    <?php endif; ?>
    <?php if($mean / count($ratting) >= 3 && $mean / count($ratting) < 4): ?>
        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
        <span class="fa fa-star" style="font-size: 14px;"></span>
        <span class="fa fa-star" style="font-size: 14px;"></span>
    <?php endif; ?>
    <?php if($mean / count($ratting) >= 4 && $mean / count($ratting) < 5): ?>
        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
        <span class="fa fa-star" style="font-size: 14px;"></span>
    <?php endif; ?>
    <?php if($mean / count($ratting) == 5): ?>
        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
    <?php endif; ?>
    <?php echo e($mean / count($ratting)); ?> <small>(<?php echo e(count($ratting)); ?>)</small>
    <?php $__currentLoopData = $rat->where('user_id', Auth::user()->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-flex justify-content-center">
            <form class="rating display-1">
                <label>
                    <input type="radio" <?php if($item->stars == 1): ?> checked <?php endif; ?> name="stars" id="radio"
                        onclick="ratUpd(<?php echo e($product->id); ?>)" class="stars" value="1" />
                    <span class="icon">★</span>
                </label>
                <label>
                    <input type="radio" <?php if($item->stars == 2): ?> checked <?php endif; ?> name="stars" id="radio"
                        onclick="ratUpd(<?php echo e($product->id); ?>)" class="stars" value="2" />
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                </label>
                <label>
                    <input type="radio" <?php if($item->stars == 3): ?> checked <?php endif; ?> name="stars" id="radio"
                        onclick="ratUpd(<?php echo e($product->id); ?>)" class="stars" value="3" />
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                </label>
                <label>
                    <input type="radio" <?php if($item->stars == 4): ?> checked <?php endif; ?> name="stars" id="radio"
                        onclick="ratUpd(<?php echo e($product->id); ?>)" class="stars" value="4" />
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                </label>
                <label>
                    <input type="radio" <?php if($item->stars == 5): ?> checked <?php endif; ?> name="stars" id="radio"
                        onclick="ratUpd(<?php echo e($product->id); ?>)" class="stars" value="5" />
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                </label>
            </form>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
    <?php if(auth()->guard()->check()): ?>

        <div class="d-flex justify-content-center">
            <form class="rating display-1">
                <label>
                    <input type="radio" name="stars" id="radio" onclick="ratAdd(<?php echo e($product->id); ?>)"
                        class="stars" value="1" />
                    <span class="icon">★</span>
                </label>
                <label>
                    <input type="radio" name="stars" id="radio" onclick="ratAdd(<?php echo e($product->id); ?>)"
                        class="stars" value="2" />
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                </label>
                <label>
                    <input type="radio" name="stars" id="radio" onclick="ratAdd(<?php echo e($product->id); ?>)"
                        class="stars" value="3" />
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                </label>
                <label>
                    <input type="radio" name="stars" id="radio" onclick="ratAdd(<?php echo e($product->id); ?>)"
                        class="stars" value="4" />
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                </label>
                <label>
                    <input type="radio" name="stars" id="radio" onclick="ratAdd(<?php echo e($product->id); ?>)"
                        class="stars" value="5" />
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                    <span class="icon">★</span>
                </label>
            </form>
        </div>
    <?php endif; ?>

<?php endif; ?>
<!-- foreach -->
<?php $__currentLoopData = $ratting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="d-flex flex-start my-4">
        <img class="rounded-circle shadow-1-strong me-3" src="<?php echo e(asset('assets/avatar/' . $rats->user->avatar)); ?>"
            alt="avatar" width="40" height="40" />
        <div class="flex-grow-1 flex-shrink-1">
            <div>
                <div class="d-flex justify-content-between align-items-center">
                    <p class="mb-1 fw-bold text-capitalize">
                        <?php echo e($rats->user->name); ?> <span class="small" style="font-size: 12px"> -
                            <?php echo e($rats->created_at); ?></span>
                    </p>
                </div>
                <p class="small mb-0">
                    <?php if($rats->stars == 1): ?>
                        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
                        <span class="fa fa-star" style="font-size: 14px;"></span>
                        <span class="fa fa-star" style="font-size: 14px;"></span>
                        <span class="fa fa-star" style="font-size: 14px;"></span>
                        <span class="fa fa-star" style="font-size: 14px;"></span>
                    <?php endif; ?>
                    <?php if($rats->stars == 2): ?>
                        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
                        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
                        <span class="fa fa-star" style="font-size: 14px;"></span>
                        <span class="fa fa-star" style="font-size: 14px;"></span>
                        <span class="fa fa-star" style="font-size: 14px;"></span>
                    <?php endif; ?>
                    <?php if($rats->stars == 3): ?>
                        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
                        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
                        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
                        <span class="fa fa-star" style="font-size: 14px;"></span>
                        <span class="fa fa-star" style="font-size: 14px;"></span>
                    <?php endif; ?>
                    <?php if($rats->stars == 4): ?>
                        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
                        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
                        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
                        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
                        <span class="fa fa-star" style="font-size: 14px;"></span>
                    <?php endif; ?>
                    <?php if($rats->stars == 5): ?>
                        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
                        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
                        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
                        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
                        <span class="fa fa-star text-warning" style="font-size: 14px;"></span>
                    <?php endif; ?>

                </p>
            </div>

        </div>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\Server\htdocs\joki\Restani\Restani\resources\views/shop/elements/ratting.blade.php ENDPATH**/ ?>