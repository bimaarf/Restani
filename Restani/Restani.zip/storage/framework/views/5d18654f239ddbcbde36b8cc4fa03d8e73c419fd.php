
<?php $__env->startSection('welcome', 'active'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Background image -->
    <div id="intro-example" class="p-5 mt-n2 text-center bg-image" style="
    background-image: url('http://sitimustiani.com/wp-content/uploads/2020/09/Ranca-Bali-Ciwidey.jpg'); height: 95vh;">
      <div class="mask" style="background-color: rgba(0, 0, 0, 0.39)">
          <div class="d-flex justify-content-center align-items-center h-100">
              <div class="text-white">
                  <h1 class="mb-3 fw-bold display-1">Restani</h1>
                  <h6 class="mb-4 fs-2 display-6">Temukan hasil pertanian dan perkebunan terdekat tanpa perantara</h6>
                  <a class="btn btn-success btn-lg text-capitalize fs-5 fw-normal rounded-pill mt-5 m-2" href="#"
                      role="button">Mulai Sekarang</a>
              </div>
          </div>
      </div>
  </div>
  <!-- Background image -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pages.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Server\htdocs\joki\Restani\Restani\resources\views/welcome.blade.php ENDPATH**/ ?>