
<?php $__env->startSection('shop', 'active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-lg mt-4">
        <?php echo $__env->make('shop.modal.modal_add_product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="product">

        </div>
            
    </div>
    <script>
        window.onload = function() {
            shopElement();
        }
    </script>
<?php $__env->stopSection(); ?>
<script>

</script>

<?php echo $__env->make('layouts.pages.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Server\htdocs\joki\Restani\Restani\resources\views/shop/product.blade.php ENDPATH**/ ?>