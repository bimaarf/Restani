<?php if($num > 0): ?>

<button onclick="favDel(<?php echo e($product->id); ?>)" type="submit"
    class="far fa-heart bg-danger rounded-circle p-3 text-white float-right mt-n2 btn btn-lg"></button>
<?php else: ?>

<button onclick="favAdd(<?php echo e($product->id); ?>)" type="submit"
    class="far fa-heart bg-primary rounded-circle p-3 text-white float-right mt-n2 btn btn-lg"></button>
<?php endif; ?>
<?php /**PATH D:\Server\htdocs\joki\Restani\Restani\resources\views/shop/elements/favorite.blade.php ENDPATH**/ ?>