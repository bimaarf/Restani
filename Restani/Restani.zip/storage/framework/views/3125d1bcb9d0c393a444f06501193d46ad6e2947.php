
<?php $__env->startSection('content'); ?>
    <div class="container card mt-2">
        <div class="row">
            <div class="col-lg-4 my-2 card-body">

                <div id="carouselBasicExample" class="carousel slide carousel-fade" data-mdb-ride="carousel">
                    <div class="carousel-indicators">
                        <?php $__currentLoopData = json_decode($product->foto); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button type="button" data-mdb-target="#carouselBasicExample"
                                data-mdb-slide-to="<?php echo e($key); ?>" class="<?php echo e($key == 0 ? 'active' : ''); ?>"
                                aria-current="true" aria-label="Slide 1"></button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="carousel-inner">

                        <?php $__currentLoopData = json_decode($product->foto); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
                                <img src="<?php echo e(asset('product/' . $slider)); ?>" class="img-fuild img-thumbnail"
                                    style="height: 300px;width:400px;object-position: center;overflow: hidden;object-fit: cover;"
                                    alt="...">

                                <div class="carousel-caption d-none d-md-block">
                                    <h5 class="text-capitalize">Stok Tersedia</h5>
                                    <p><?php echo e($product->stok); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                    <button class="carousel-control-prev" type="button" data-mdb-target="#carouselBasicExample"
                        data-mdb-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-mdb-target="#carouselBasicExample"
                        data-mdb-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>

            </div>
            <div class="col-lg-8 card-body">
                <div class="float-left">
                    <p class="text-black-50 fw-bold h5"><?php echo e($product->title); ?></p>
                    <div class="my-1">
                        <?php if(count($ratting) > 0): ?>
                            <?php if($mean / count($ratting) > 0 && $mean / count($ratting) < 2): ?>
                                <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
                                <span class="fa fa-star" style="font-size: 10px;"></span>
                                <span class="fa fa-star" style="font-size: 10px;"></span>
                                <span class="fa fa-star" style="font-size: 10px;"></span>
                                <span class="fa fa-star" style="font-size: 10px;"></span>
                            <?php endif; ?>
                            <?php if($mean / count($ratting) >= 2 && $mean / count($ratting) < 3): ?>
                                <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
                                <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
                                <span class="fa fa-star" style="font-size: 10px;"></span>
                                <span class="fa fa-star" style="font-size: 10px;"></span>
                                <span class="fa fa-star" style="font-size: 10px;"></span>
                            <?php endif; ?>
                            <?php if($mean / count($ratting) >= 3 && $mean / count($ratting) < 4): ?>
                                <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
                                <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
                                <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
                                <span class="fa fa-star" style="font-size: 10px;"></span>
                                <span class="fa fa-star" style="font-size: 10px;"></span>
                            <?php endif; ?>
                            <?php if($mean / count($ratting) >= 4 && $mean / count($ratting) < 5): ?>
                                <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
                                <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
                                <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
                                <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
                                <span class="fa fa-star" style="font-size: 10px;"></span>
                            <?php endif; ?>
                            <?php if($mean / count($ratting) == 5): ?>
                                <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
                                <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
                                <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
                                <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
                                <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
                            <?php endif; ?>
                            <br>
                            <div style="font-size: 12px;">
                                <?php echo e($mean / count($ratting)); ?> <small class="text-black-50">(<?php echo e(count($ratting)); ?>

                                    Ulasan)</small>
                            </div>

                        <?php else: ?>
                            <span class="fa fa-star" style="font-size: 10px;"></span>
                            <span class="fa fa-star" style="font-size: 10px;"></span>
                            <span class="fa fa-star" style="font-size: 10px;"></span>
                            <span class="fa fa-star" style="font-size: 10px;"></span>
                            <span class="fa fa-star" style="font-size: 10px;"></span>
                            <div style="font-size: 12px;">
                                <small class="text-black-50">(Belum ada ulasan)</small>
                            </div>
                        <?php endif; ?>

                    </div>
                    <p class="h5 text-success">Rp <?php echo e($product->harga); ?></p>
                </div>
                <div id="favorite"></div>

                <br><br><br><br><br>
                <span class="float-end"><i class="fas fa-tags"></i> <?php echo e($product->kategori->name); ?></span>
                <?php if($product->stok > 0): ?>
                    <i class="fa fa-check bg-success text-white rounded-circle p-1"></i> <span
                        class="ml-2 fw-bold h6 text-black-50">Stok Tersedia</span> <span
                        class="text-info"><?php echo e($product->stok); ?></span>
                <?php else: ?>
                    <span class="ml-2 fw-bold h6 text-danger">Stok Habis</span>
                <?php endif; ?>
                <div class="float-none">
                    <p class="text-body border-bottom pb-4"><?php echo $product->desc; ?></p>

                    <div class="float-left">

                        <label for="jumlah">Jumlah</label>
                        <div class="number-input form-group ml-3 border-0 float-right">
                            <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()"
                                class="minus text-black-50 border" style="height: 30px ; width: 20px"></button>

                            <input id="jumlah" class="text-center border" min="1" max="<?php echo e($product->stok); ?>"
                                name="quantity" value="1" type="number" style="width: 60px; height: 30px;" disabled>

                            <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()"
                                class="plus text-black-50 border" style="height: 30px ; width: 20px"></button>
                        </div>

                    </div>

                    <button onclick="cartAdd(<?php echo e($product->id); ?>)"
                        class="btn btn-success rounded my-1 mx-4 text-capitalize float-right" type="submit"> <i
                            class="fa fa-shopping-cart"></i><span class="d-lg-inline collapse"> Masukkan
                            Keranjang</span></button>
                    <button onclick="bookAdd(<?php echo e($product->id); ?>)"
                        class="btn btn-info rounded my-1 mx-4 text-capitalize w-50 float-right"
                        type="submit">Re-Booking</button>
                    <button onclick="subAdd(<?php echo e($product->id); ?>)"
                        class="btn btn-info rounded my-1 mx-4 text-capitalize w-50 float-right"
                        type="submit">Langganan</button>
                    <?php if(auth()->guard()->check()): ?>

                        <a target="__blank"
                            href="https://wa.me/<?php echo e($product->user->no_telp); ?>?text= *Re-Booking!*%0A Hallo kak saya <?php echo e(Auth::user()->name); ?>, %0A _Produk yg saya pesan_ %0A  %0A <?php echo e($product->title); ?>%0A       jumlah ="
                            class="btn btn-info rounded my-1 mx-4 text-capitalize w-50 float-right">Bayar
                            Sekarang</a>
                    <?php endif; ?>


                </div>
                <div class="float-left mt-4">

                    <div class="card my-4">
                        <div class="card-body">
                            <form action="<?php echo e(route('chats.addRomm')); ?>" method="get">
                                <img src="<?php echo e(asset('assets/avatar/' . $product->user->avatar)); ?>" width="40" alt="">
                                <span class="fw-bold text-capitalize"><?php echo e($product->user->name); ?></span>
                                <input type="hidden" name="user_id" value="<?php echo e($product->user->id); ?>">
                                <a href="<?php echo e(route('profile.index', ['name' => $product->user->name])); ?>"
                                    class="btn btn-success rounded-6 text-capitalize mx-4">Kunjungi Petani</a>
                                <?php if(auth()->guard()->check()): ?>

                                    <?php if(Auth::user()->hasRole('user')): ?>

                                        <button class="btn btn-outline-light text-black-50 rounded-6 text-capitalize ">Chat
                                            Petani </button>
                                    <?php endif; ?>
                                <?php endif; ?>


                            </form>
                        </div>
                    </div>
                    <div class="form-group">
                        <i class="fa fa-map-marker-alt text-success"></i>
                        <label for="lokasi">Lokasi</label>
                        <span class="border-bottom border-primary px-1 ml-4"><?php echo e($product->lokasi); ?></span>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <ul class="nav nav-tabs mb-3" id="myTab0" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link text-capitalize fs-6 active" id="home-tab0" data-mdb-toggle="tab"
                            data-mdb-target="#home0" type="button" role="tab" aria-controls="home" aria-selected="true">
                            Comments
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link text-capitalize fs-6" onclick="ratShow(<?php echo e($product->id); ?>)"
                            id="profile-tab0" data-mdb-toggle="tab" data-mdb-target="#profile0" type="button" role="tab"
                            aria-controls="profile" aria-selected="false">
                            Reviews
                        </button>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent0">
                    <div class="tab-pane fade show border p-4 rounded-6 active" id="home0" role="tabpanel"
                        aria-labelledby="home-tab0">
                        <a href="#!" class="float-right" onclick="comment()"><i class="fas fa-reply fa-xs"></i><span
                                class="small">
                                Add comment</span></a>
                        <h4 class="text-center mb-4 pb-2">Komentar</h4>
                        <form id="form-comment" class="input-group my-4"
                            action="<?php echo e(route('comment.store', ['id' => $product->id])); ?>">
                            <input id="message" type="text" value="" maxlength="250"
                                class="form-control border-0 border-bottom" name="message" placeholder='Ketikkan komentar..'
                                style="border-color: inherit;
                                                                                        -webkit-box-shadow: none;
                                                                                        box-shadow: none;">

                            <button onclick="addComment(<?php echo e($product->id); ?>)" type="submit"
                                class="btn btn-outline-success fas fa-paper-plane"></button>
                        </form>
                        
                        <div id="box-comment"></div>
                    </div>
                    <div class="tab-pane fade border p-4 rounded-6" id="profile0" role="tabpanel"
                        aria-labelledby="profile-tab0">
                        <div id="ratting"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>

    <script>
        var subCondition = true;
        var comCondition = true;

        function commentElement(id) {
            const url = '/comment/show/' + id
            $.get(url, {}, function(comments, status) {
                const query = "#box-comment"
                $(query).html(comments)
            })
        }

        function comment() {
            if (comCondition == true) {
                $("#form-comment").addClass('d-none');
                console.log(comCondition)
                comCondition = false
            } else {
                $("#form-comment").removeClass('d-none');
                console.log(comCondition)
                comCondition = true
            }
        }

        function subComment(id) {
            if (subCondition == true) {
                $("#form-sub" + id).removeClass('d-none');

                subCondition = false;

            } else if (subCondition == false) {
                $("#form-sub" + id).addClass('d-none');

                subCondition = true;
            }
        }

        setTimeout(() => {
            commentElement(<?php echo e($product->id); ?>);

        }, 1000);

        function addComment(id) {
            const url = "/comment/add/" + id
            const formComment = '#form-comment'
            $('.btn').attr('disabled', true);
            $.ajax({
                url: url,
                type: "GET",
                data: $(formComment).serialize(),
                success: function(response) {
                    $('.btn').attr('disabled', false);
                    $('#message').val('');
                    commentElement(id)
                },
                error: function(response) {
                    if ($('#message').val()) {
                        $('.btn').attr('disabled', false);
                        swal({
                            title: "Error!",
                            text: "Anda perlu login!",
                            type: "warning",
                            confirmButtonClass: "btn-danger",
                            confirmButtonText: "Yes!",
                            showCancelButton: false,
                        })
                    } else {
                        $('.btn').attr('disabled', false);
                        swal({
                            title: "Error!",
                            text: "Text tidak boleh kosong!",
                            type: "error",
                            confirmButtonClass: "btn-danger",
                            confirmButtonText: "Yes!",
                            showCancelButton: false,
                        })
                    }
                }
            })
        }

        function addSub(id) {
            const url = "/sub-comment/add/" + id
            const message = $('#sub-message' + id).val()
            $('.btn').attr('disabled', true);
            $.ajax({
                url: url,
                type: "GET",
                data: {
                    message: message
                },
                success: function(response) {
                    $('.btn').attr('disabled', false);
                    $('#sub-message' + id).val('');
                    commentElement(<?php echo e($product->id); ?>)
                },
                error: function(response) {
                    if ($('#sub-message' + id).val()) {
                        $('.btn').attr('disabled', false);
                        swal({
                            title: "Error!",
                            text: "Anda perlu login!",
                            type: "warning",
                            confirmButtonClass: "btn-danger",
                            confirmButtonText: "Yes!",
                            showCancelButton: false,
                        })
                    } else {
                        $('.btn').attr('disabled', false);
                        swal({
                            title: "Error!",
                            text: "Text tidak boleh kosong!",
                            type: "error",
                            confirmButtonClass: "btn-danger",
                            confirmButtonText: "Yes!",
                            showCancelButton: false,
                        })
                    }

                }
            })
        }


        document.addEventListener('trix-file-accept', function(e) {
            e.preventDefault()
            ''
        })
        const product_id = '<?php echo e($product->id); ?>';
        window.onload = function() {
            favShow(product_id);
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pages.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Server\htdocs\joki\Restani\Restani\resources\views/shop/preview.blade.php ENDPATH**/ ?>