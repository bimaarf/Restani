<!-- foreach -->
<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="d-flex flex-start my-4">
        <img class="rounded-circle shadow-1-strong me-3"
            src="<?php echo e(asset('assets/avatar/' . $comment->user->avatar)); ?>" alt="avatar" width="40" height="40" />
        <div class="flex-grow-1 flex-shrink-1">
            <div>
                <div class="d-flex justify-content-between align-items-center">
                    <p class="mb-1 fw-bold text-capitalize">
                        <?php echo e($comment->user->name); ?> <span class="small"
                            style="font-size: 12px"> - <?php echo e($comment->created_at); ?></span>
                    </p>
                    <a href="#!" onclick="subComment(<?php echo e($comment->id); ?>)"><i class="fas fa-reply fa-xs"></i><span
                            class="small">
                            reply</span></a>
                </div>
                <p class="small mb-0">
                    <?php echo e($comment->message); ?>

                </p>
            </div>
            <div class="row">
                <div class="col-lg-6 col-12 input-group d-none" id="form-sub<?php echo e($comment->id); ?>">
                    <input id="sub-message<?php echo e($comment->id); ?>" type="text" value=""
                        class="form-control border-0 border-bottom" maxlength="250" name="message" placeholder='Ketikkan komentar..'
                        style="border-color: inherit;
                                        -webkit-box-shadow: none;
                                        box-shadow: none;">

                    <button onclick="addSub(<?php echo e($comment->id); ?>)" type="submit"
                        class="btn btn-outline-success fas fa-paper-plane"></button>
                </div>
            </div>

            <?php $__currentLoopData = $subs->where('comment_id', $comment->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex flex-start mt-4">
                        <img class="rounded-circle shadow-1-strong me-3"
                            src="<?php echo e(asset('assets/avatar/' . $sub->user->avatar)); ?>" alt="avatar" width="30"
                            height="30" />
                    <div class="flex-grow-1 flex-shrink-1">
                        <div>
                            <div class="d-flex justify-content-between align-items-center">
                                <p class="mb-1 fw-bold text-capitalize">
                                    <?php echo e($sub->user->name); ?> <span class="small" style="font-size: 12px">- <?php echo e($sub->created_at); ?></span>
                                </p>
                            </div>
                            <p class="small mb-0">
                                <?php echo e($sub->message); ?>

                            </p>
                        </div>
                    </div>
                </div>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\Server\htdocs\joki\Restani\Restani\resources\views/shop/elements/comment.blade.php ENDPATH**/ ?>