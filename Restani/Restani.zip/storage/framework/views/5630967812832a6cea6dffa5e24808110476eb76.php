<?php if(count($ratting) > 0): ?>
    <?php if($mean / count($ratting) > 0 && $mean / count($ratting) < 2): ?>
        <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
        <span class="fa fa-star" style="font-size: 10px;"></span>
        <span class="fa fa-star" style="font-size: 10px;"></span>
        <span class="fa fa-star" style="font-size: 10px;"></span>
        <span class="fa fa-star" style="font-size: 10px;"></span>
    <?php endif; ?>
    <?php if($mean / count($ratting) >= 2 && $mean / count($ratting) < 3): ?>
        <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
        <span class="fa fa-star" style="font-size: 10px;"></span>
        <span class="fa fa-star" style="font-size: 10px;"></span>
        <span class="fa fa-star" style="font-size: 10px;"></span>
    <?php endif; ?>
    <?php if($mean / count($ratting) >= 3 && $mean / count($ratting) < 4): ?>
        <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
        <span class="fa fa-star" style="font-size: 10px;"></span>
        <span class="fa fa-star" style="font-size: 10px;"></span>
    <?php endif; ?>
    <?php if($mean / count($ratting) >= 4 && $mean / count($ratting) < 5): ?>
        <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
        <span class="fa fa-star" style="font-size: 10px;"></span>
    <?php endif; ?>
    <?php if($mean / count($ratting) == 5): ?>
        <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
        <span class="fa fa-star text-warning" style="font-size: 10px;"></span>
    <?php endif; ?>
    <br>
    <div style="font-size: 12px;">
        <?php echo e($mean / count($ratting)); ?> <small class="text-black-50">(<?php echo e(count($ratting)); ?> Ulasan)</small>
    </div>

<?php else: ?>
    <span class="fa fa-star" style="font-size: 10px;"></span>
    <span class="fa fa-star" style="font-size: 10px;"></span>
    <span class="fa fa-star" style="font-size: 10px;"></span>
    <span class="fa fa-star" style="font-size: 10px;"></span>
    <span class="fa fa-star" style="font-size: 10px;"></span>
    <div style="font-size: 12px;">
        <small class="text-black-50">(Belum ada ulasan)</small>
    </div>
<?php endif; ?>
<?php /**PATH D:\Server\htdocs\joki\Restani\Restani\resources\views/shop/elements/stars.blade.php ENDPATH**/ ?>