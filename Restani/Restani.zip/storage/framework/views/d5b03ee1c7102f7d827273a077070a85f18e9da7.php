
<?php $__env->startSection('subscribe', 'active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="card">
            <div class="car-header">
                <div class="card-header bg-primary" style="border-top-left-radius: 30px; border-top-right-radius: 30px;">
                    <h5 class="text-white text-center">Langganan</h5>
                </div>
                <div class="card-body" id="subscribe">

                </div>
            </div>
        </div>
    </div>

    <script>
        window.onload = function() {
            tableSub();
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pages.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Server\htdocs\joki\Restani\Restani\resources\views/shop/subscribe.blade.php ENDPATH**/ ?>