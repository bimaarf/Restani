
<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div id="table"></div>
    </div>
    <script>
        window.onload = function() {
            table();
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pages.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Server\htdocs\joki\Restani\Restani\resources\views/shop/cart.blade.php ENDPATH**/ ?>