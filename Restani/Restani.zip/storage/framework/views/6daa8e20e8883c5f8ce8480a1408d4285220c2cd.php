<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $count = 0; ?>
    <div id="toko<?php echo e($user->id); ?>">

        <?php
            $invoice = [];
        ?>

        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($booking->product->user_id == $user->id): ?>
                <?php
                    $total += $booking->total;
                    $buy = [
                        'mitra_id' => $booking->product->user_id,
                        'title' => $booking->product->title,
                        'jumlah' => $booking->jumlah,
                        'subtotal' => $booking->total,
                    ];
                    array_push($invoice, $buy);
                ?>

                <div class="row mt-2 py-lg-4 pb-2">
                    <div class="col-4 col-lg-3">
                        <?php
                        $decode = json_decode($booking->product->foto, true);
                        for ($i=0; $i < 1 ; $i++) { 
                        ?>
                        <img src="<?php echo e(asset('product/' . $decode[0])); ?>"
                            class="img-fluid img-thumbnail text-center border rounded" alt=".."
                            style="object-position: center;overflow: hidden;object-fit: cover;">
                        <?php } ?>

                    </div>
                    <div class="col-8 col-lg-9">
                        <span class="fw-bold text-black-50"><?php echo e($booking->product->title); ?></span>
                        <div class="row">
                            <div class="col-lg-6">
                                <h6 class="text-success">Rp <?php echo e($booking->total); ?></h6>
                                <p class="text-black-50 small">Rp <?php echo e($booking->product->harga); ?> / kg</p>
                            </div>
                            <div class="col-lg-6">
                                <a class="mx-1" onclick="bookDelete(<?php echo e($booking->id); ?>)" href="#"><i
                                        class="fa fa-trash fa-pull-right link-danger"></i></a>

                                <div class="number-input form-groyp border-0">
                                    <button
                                        onclick="this.parentNode.querySelector('input[type=number]').stepDown() ,bookUpdate(<?php echo e($booking->id); ?>)"
                                        class="minus text-white bg-success"
                                        style="border-top-left-radius: 50%;border-bottom-left-radius: 50%;"></button>

                                    <input id="jumlah<?php echo e($booking->id); ?>" class="border text-center" min="1"
                                        name="quantity" value="<?php echo e($booking->jumlah); ?>" type="number"
                                        style="width: 100px;" disabled>

                                    <button
                                        onclick="this.parentNode.querySelector('input[type=number]').stepUp() ,bookUpdate(<?php echo e($booking->id); ?>)"
                                        class="plus text-white bg-success"
                                        style="border-top-right-radius: 50%; border-bottom-right-radius: 50%;"></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <hr>
        <div class="row p-lg-4">
            <div class="col-md-4 mt-2 col-lg-8">
                <h6 class="text-black-50 fw-bold">Nama Petani</h6>
                <img src="<?php echo e(asset('assets/avatar/' . $user->avatar)); ?>" class="img-thumbnail" width="40" alt="">
                <span class="fw-bold fs-6 text-capitalize"><?php echo e($user->name); ?></span>
            </div>
            <div class="col-md-8 mt-2 col-lg-4">
                <i class="fa fa-calendar-alt text-black-50"></i>
                <span class="ml-2 fs-6 fw-bold h6 text-black-50">Tanggal Booking</span>
                <input type="hidden" value="<?php echo e($user->no_telp); ?>">
                <input type="date" class="form-control my-4 rounded-6 btn btn-lg btn-success" name="tanggal"
                    id="tanggal" data-date="" data-date-format="DD MMMM YYYY">
            </div>
        </div>



        <div class="mx-4 float-lg-end">
            <span class="h5 fw-bold text-black-50">Total</span>

            <span class="h5 ml-2 fw-bold text-success">Rp <?php echo e($total); ?></span>
            <?php if(auth()->guard()->check()): ?>

                <a target="__blank"
                    href="https://wa.me/<?php echo e($user->no_telp); ?>?text= *Re-Booking!*%0A Hallo kak saya <?php echo e(Auth::user()->name); ?>, %0A _Produk yg saya pesan_ %0A  %0A <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($i++); ?>. <?php echo e($buys['title']); ?>  %0A       jumlah x <?php echo e($buys['jumlah']); ?> = *Rp <?php echo e($buys['subtotal']); ?>* %0A <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> %0A *Total = Rp <?php echo e($total); ?>* %0A      Tanggal Booking = "
                    class="btn btn-primary ml-4 px-6 btn-lg rounded-pill text-capitalize">Bayar
                    Sekarang</a>
            <?php endif; ?>
        </div>

        <br>
        <div class="card-footer my-4">
            <div class="float-none py-4 text-center">

            </div>
        </div>
        <?php $__currentLoopData = $title; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($prod['mitra_id'] == $user->id): ?>
                <?php $count = count($title); ?>
                <?php
                    $total = 0;
                ?>
            <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <?php if($count == 0): ?>
        <style>
            #toko<?php echo e($user->id); ?> {
                display: none;
            }

        </style>
    <?php endif; ?>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\Server\htdocs\joki\Restani\Restani\resources\views/shop/elements/booking.blade.php ENDPATH**/ ?>